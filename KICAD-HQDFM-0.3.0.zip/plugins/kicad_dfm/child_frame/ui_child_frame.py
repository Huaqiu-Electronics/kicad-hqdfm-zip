# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version 4.0.0-0-g0efcecf)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
from kicad_dfm.settings.single_plugin import SINGLE_PLUGIN
import wx.dataview
from kicad_dfm.custom_contral.custom_listbox import CustomListBox

###########################################################################
## Class UiChildDialog
###########################################################################

class UiChildDialog ( wx.Dialog ):

	def __init__( self, parent ):
		wx.Dialog.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 750,600 ), style = wx.DEFAULT_DIALOG_STYLE|wx.STAY_ON_TOP )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		kicad_main_window = SINGLE_PLUGIN.get_main_wind()
		bSizer1 = wx.BoxSizer( wx.VERTICAL )

		self.m_panel1 = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer2 = wx.BoxSizer( wx.HORIZONTAL )

		self.layer_panel = wx.Panel( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer3 = wx.BoxSizer( wx.VERTICAL )

		self.text_layer = wx.TextCtrl( self.layer_panel, wx.ID_ANY, _(u"Layer"), wx.DefaultPosition, wx.DefaultSize, wx.TE_CENTER )
		bSizer3.Add( self.text_layer, 0, wx.EXPAND, 0 )

		lst_layerChoices = []
		self.lst_layer = wx.ListBox( self.layer_panel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, lst_layerChoices, wx.LB_EXTENDED )
		bSizer3.Add( self.lst_layer, 1, wx.ALL|wx.EXPAND, 0 )

		self.check_box = wx.CheckBox( self.layer_panel, wx.ID_ANY, _(u"Keep selected layers"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.check_box, 0, wx.ALL, 5 )

		combo_boxChoices = [ _(u"Show all"), _(u"!! (Alarm)") ]
		self.combo_box = wx.ComboBox( self.layer_panel, wx.ID_ANY, _(u"Show all"), wx.DefaultPosition, wx.DefaultSize, combo_boxChoices, 0 )
		self.combo_box.SetSelection( 0 )
		bSizer3.Add( self.combo_box, 0, wx.ALL|wx.EXPAND, 5 )


		self.layer_panel.SetSizer( bSizer3 )
		self.layer_panel.Layout()
		bSizer3.Fit( self.layer_panel )
		bSizer2.Add( self.layer_panel, 1, wx.EXPAND |wx.ALL, 0 )

		self.class_panel = wx.Panel( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer4 = wx.BoxSizer( wx.VERTICAL )

		self.text_analysis_type = wx.TextCtrl( self.class_panel, wx.ID_ANY, _(u"Problem"), wx.DefaultPosition, wx.DefaultSize, wx.TE_CENTER )
		bSizer4.Add( self.text_analysis_type, 0, wx.ALL|wx.EXPAND, 0 )

		lst_analysis_typeChoices = []
		self.lst_analysis_type = wx.ListBox( self.class_panel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, lst_analysis_typeChoices, wx.LB_EXTENDED )
		bSizer4.Add( self.lst_analysis_type, 1, wx.ALL|wx.EXPAND, 0 )


		self.class_panel.SetSizer( bSizer4 )
		self.class_panel.Layout()
		bSizer4.Fit( self.class_panel )
		bSizer2.Add( self.class_panel, 1, wx.EXPAND |wx.ALL, 0 )

		self.result_panel = wx.Panel( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer5 = wx.BoxSizer( wx.VERTICAL )

		self.text_analysis_result = wx.TextCtrl( self.result_panel, wx.ID_ANY, _(u"Occurrences(Click to view)"), wx.DefaultPosition, wx.DefaultSize, wx.TE_CENTER )
		bSizer5.Add( self.text_analysis_result, 0, wx.ALL|wx.EXPAND, 0 )

		self.lst_analysis_result1 = wx.dataview.DataViewListCtrl( self.result_panel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.dataview.DV_NO_HEADER|wx.dataview.DV_ROW_LINES|wx.dataview.DV_SINGLE )
		bSizer5.Add( self.lst_analysis_result1, 1, wx.ALL|wx.EXPAND, 0 )

		bSizer6 = wx.BoxSizer( wx.HORIZONTAL )

		self.first_button = wx.Button( self.result_panel, wx.ID_ANY, _(u"First"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.first_button, 1, wx.ALL, 2 )

		self.back_button = wx.Button( self.result_panel, wx.ID_ANY, _(u"<<"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.back_button, 1, wx.ALL, 2 )

		self.next_button = wx.Button( self.result_panel, wx.ID_ANY, _(u">>"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.next_button, 1, wx.ALL, 2 )

		self.last_button = wx.Button( self.result_panel, wx.ID_ANY, _(u"Last"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.last_button, 1, wx.ALL, 2 )


		bSizer5.Add( bSizer6, 0, wx.EXPAND, 0 )


		self.result_panel.SetSizer( bSizer5 )
		self.result_panel.Layout()
		bSizer5.Fit( self.result_panel )
		bSizer2.Add( self.result_panel, 1, wx.EXPAND |wx.ALL, 0 )


		self.m_panel1.SetSizer( bSizer2 )
		self.m_panel1.Layout()
		bSizer2.Fit( self.m_panel1 )
		bSizer1.Add( self.m_panel1, 1, wx.ALL|wx.EXPAND, 0 )

		self.m_panel5 = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		self.m_panel5.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_WINDOW ) )

		bSizer7 = wx.BoxSizer( wx.VERTICAL )

		sbSizer2 = wx.StaticBoxSizer( wx.StaticBox( self.m_panel5, wx.ID_ANY, _(u"Rule description") ), wx.VERTICAL )

		self.bmp = wx.StaticBitmap( sbSizer2.GetStaticBox(), wx.ID_ANY, wx.NullBitmap, wx.DefaultPosition, wx.DefaultSize, 0 )
		sbSizer2.Add( self.bmp, 1, wx.ALL|wx.EXPAND, 5 )


		bSizer7.Add( sbSizer2, 1, wx.ALL|wx.EXPAND, 5 )


		self.m_panel5.SetSizer( bSizer7 )
		self.m_panel5.Layout()
		bSizer7.Fit( self.m_panel5 )
		bSizer1.Add( self.m_panel5, 1, wx.ALL|wx.EXPAND, 0 )


		self.SetSizer( bSizer1 )
		self.Layout()

		self.Centre( wx.BOTH )

	def __del__( self ):
		pass


###########################################################################
## Class MyDialog2
###########################################################################

class MyDialog2 ( wx.Dialog ):

	def __init__( self, parent ):
		wx.Dialog.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 282,349 ), style = wx.DEFAULT_DIALOG_STYLE )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		bSizer15 = wx.BoxSizer( wx.VERTICAL )

		lst_analysis_resultChoices = []
		self.lst_analysis_result = wx.ListBox( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, lst_analysis_resultChoices, wx.LB_SINGLE )
		bSizer15.Add( self.lst_analysis_result, 1, wx.ALL|wx.EXPAND, 0 )

		bSizer16 = wx.BoxSizer( wx.VERTICAL )


		bSizer15.Add( bSizer16, 1, wx.EXPAND, 5 )

		lst_analysis_resultChoices = []
		self.lst_analysis_result = CustomListBox( self.result_panel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, lst_analysis_resultChoices, wx.LB_SINGLE )

		bSizer15.Add( self.lst_analysis_result2, 1, wx.ALL|wx.EXPAND, 0 )

		self.lst_analysis_result1 = wx.dataview.DataViewListCtrl( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.dataview.DV_NO_HEADER|wx.dataview.DV_ROW_LINES|wx.dataview.DV_SINGLE )
		self.lst_analysis_result1.SetFont( wx.Font( 9, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, "宋体" ) )

		bSizer15.Add( self.lst_analysis_result1, 1, wx.ALL|wx.EXPAND, 0 )


		self.SetSizer( bSizer15 )
		self.Layout()

		self.Centre( wx.BOTH )

	def __del__( self ):
		pass


###########################################################################
## Class UiChildFrame
###########################################################################

class UiChildFrame ( wx.Frame ):

	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 750,600 ), style = wx.DEFAULT_FRAME_STYLE|wx.STAY_ON_TOP|wx.TAB_TRAVERSAL )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		bSizer1 = wx.BoxSizer( wx.VERTICAL )

		self.m_panel1 = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer2 = wx.BoxSizer( wx.HORIZONTAL )

		self.layer_panel = wx.Panel( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer3 = wx.BoxSizer( wx.VERTICAL )

		self.text = wx.TextCtrl( self.layer_panel, wx.ID_ANY, _(u"Layer"), wx.DefaultPosition, wx.DefaultSize, wx.TE_CENTER )
		bSizer3.Add( self.text, 0, wx.EXPAND, 0 )

		lstChoices = []
		self.lst = wx.ListBox( self.layer_panel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, lstChoices, 0 )
		bSizer3.Add( self.lst, 1, wx.ALL|wx.EXPAND, 0 )

		self.check_box = wx.CheckBox( self.layer_panel, wx.ID_ANY, _(u"Keep selected layers"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.check_box, 0, wx.ALL, 5 )

		combo_boxChoices = [ _(u"Show all"), _(u"!!") ]
		self.combo_box = wx.ComboBox( self.layer_panel, wx.ID_ANY, _(u"Show all"), wx.DefaultPosition, wx.DefaultSize, combo_boxChoices, 0 )
		self.combo_box.SetSelection( 0 )
		bSizer3.Add( self.combo_box, 0, wx.ALL|wx.EXPAND, 5 )


		self.layer_panel.SetSizer( bSizer3 )
		self.layer_panel.Layout()
		bSizer3.Fit( self.layer_panel )
		bSizer2.Add( self.layer_panel, 1, wx.EXPAND |wx.ALL, 0 )

		self.class_panel = wx.Panel( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer4 = wx.BoxSizer( wx.VERTICAL )

		self.text_analysis_type = wx.TextCtrl( self.class_panel, wx.ID_ANY, _(u"Problem"), wx.DefaultPosition, wx.DefaultSize, wx.TE_CENTER )
		bSizer4.Add( self.text_analysis_type, 0, wx.ALL|wx.EXPAND, 0 )

		lst_analysis_typeChoices = []
		self.lst_analysis_type = wx.ListBox( self.class_panel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, lst_analysis_typeChoices, 0 )
		bSizer4.Add( self.lst_analysis_type, 1, wx.ALL|wx.EXPAND, 0 )


		self.class_panel.SetSizer( bSizer4 )
		self.class_panel.Layout()
		bSizer4.Fit( self.class_panel )
		bSizer2.Add( self.class_panel, 1, wx.EXPAND |wx.ALL, 0 )

		self.result_panel = wx.Panel( self.m_panel1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer5 = wx.BoxSizer( wx.VERTICAL )

		self.text_analysis_result = wx.TextCtrl( self.result_panel, wx.ID_ANY, _(u"Occurrences(Click to view)"), wx.DefaultPosition, wx.DefaultSize, wx.TE_CENTER )
		bSizer5.Add( self.text_analysis_result, 0, wx.ALL|wx.EXPAND, 0 )

		lst_analysis_resultChoices = []
		self.lst_analysis_result = wx.ListBox( self.result_panel, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, lst_analysis_resultChoices, 0 )
		bSizer5.Add( self.lst_analysis_result, 1, wx.ALL|wx.EXPAND, 0 )

		bSizer6 = wx.BoxSizer( wx.HORIZONTAL )

		self.first_button = wx.Button( self.result_panel, wx.ID_ANY, _(u"First"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.first_button, 1, wx.ALL, 2 )

		self.back_button = wx.Button( self.result_panel, wx.ID_ANY, _(u"<<"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.back_button, 1, wx.ALL, 2 )

		self.next_button = wx.Button( self.result_panel, wx.ID_ANY, _(u">>"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.next_button, 1, wx.ALL, 2 )

		self.last_button = wx.Button( self.result_panel, wx.ID_ANY, _(u"Last"), wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.last_button, 1, wx.ALL, 2 )


		bSizer5.Add( bSizer6, 0, wx.EXPAND, 0 )


		self.result_panel.SetSizer( bSizer5 )
		self.result_panel.Layout()
		bSizer5.Fit( self.result_panel )
		bSizer2.Add( self.result_panel, 1, wx.EXPAND |wx.ALL, 0 )


		self.m_panel1.SetSizer( bSizer2 )
		self.m_panel1.Layout()
		bSizer2.Fit( self.m_panel1 )
		bSizer1.Add( self.m_panel1, 2, wx.EXPAND |wx.ALL, 0 )

		self.m_panel5 = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		self.m_panel5.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_WINDOW ) )

		bSizer7 = wx.BoxSizer( wx.VERTICAL )

		sbSizer2 = wx.StaticBoxSizer( wx.StaticBox( self.m_panel5, wx.ID_ANY, _(u"Rule description") ), wx.VERTICAL )

		self.bmp = wx.StaticBitmap( sbSizer2.GetStaticBox(), wx.ID_ANY, wx.NullBitmap, wx.DefaultPosition, wx.DefaultSize, 0 )
		sbSizer2.Add( self.bmp, 1, wx.ALL|wx.EXPAND, 5 )


		bSizer7.Add( sbSizer2, 1, wx.ALL|wx.EXPAND, 5 )


		self.m_panel5.SetSizer( bSizer7 )
		self.m_panel5.Layout()
		bSizer7.Fit( self.m_panel5 )
		bSizer1.Add( self.m_panel5, 1, wx.ALL|wx.EXPAND, 0 )


		self.SetSizer( bSizer1 )
		self.Layout()

		self.Centre( wx.BOTH )

	def __del__( self ):
		pass


