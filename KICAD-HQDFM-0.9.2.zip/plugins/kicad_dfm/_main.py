from kicad_dfm._baseApp import BaseApp
from kicad_dfm.settings.single_plugin import SINGLE_PLUGIN
import wx

def _main():
        app = BaseApp()
