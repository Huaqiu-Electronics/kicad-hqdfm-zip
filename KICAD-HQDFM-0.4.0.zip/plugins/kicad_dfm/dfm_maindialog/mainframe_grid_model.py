import wx
from mainframe_grid_model import UiDfmMainframe


class MyFrame(UiDfmMainframe):
    def __init__(self, parent):
        UiDfmMainframe.__init__(self, parent)
