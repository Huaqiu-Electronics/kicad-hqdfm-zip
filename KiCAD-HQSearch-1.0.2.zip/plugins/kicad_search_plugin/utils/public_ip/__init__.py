# Copyright (c) 2021 Víctor Terrón
# Licensed under the MIT license.
# https://github.com/vterron/public-ip/

from ._ip import get, get_ip_country

__version__ = "0.12"
